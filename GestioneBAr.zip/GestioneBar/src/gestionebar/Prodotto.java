/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionebar;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/**
 *
 * @author ricca
 */

@XmlRootElement
public class Prodotto {
    
    private int ID;
    private String nome;

    public Prodotto() {
        super();
    }
    public Prodotto(int ID, String nome) {
        this.ID = ID;
        this.nome = nome;
    }
    
    @XmlAttribute
    public int getID() {
        return ID;
    }
    
    @XmlElement
    public String getNome() {
        return nome;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
}

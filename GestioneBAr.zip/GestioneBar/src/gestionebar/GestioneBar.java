/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionebar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 *
 * @author ricca
 */
public class GestioneBar {

    /**
     * @param args the command line arguments
     * @throws javax.xml.bind.JAXBException
     */
    public static void main(String[] args) throws JAXBException, FileNotFoundException {
        
        Prodotto p = new Prodotto(1,"Marmellata");
        System.out.println("ID: " + p.getID() + "  --   Nome: " + p.getNome());
        
        
        JAXBContext contextMAR = JAXBContext.newInstance(Prodotto.class);
        Marshaller marshaller = contextMAR.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        FileOutputStream filexml = new FileOutputStream("C:\\Users\\ricca\\Documents\\Eclipse-Workspace\\EsercizioJAXB\\xmldata\\esempio.xml");

        marshaller.marshal(p, filexml);         
        
        
// ###############################################################à

        File file = new File("C:\\Users\\ricca\\Documents\\Eclipse-Workspace\\EsercizioJAXB\\xmldata\\esempio.xml");
        try {

                JAXBContext contextUNM = JAXBContext.newInstance(Prodotto.class);

                Unmarshaller unmarshaller = contextUNM.createUnmarshaller();
                //unmarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

                Prodotto p2 = (Prodotto)unmarshaller.unmarshal(file);

                System.out.println("Dati: ID: " + p2.getID() + "\nNome: " + p2.getNome());


        } catch (JAXBException e) {

        }
        
        
    }
    
}
